### Table of contents:
Introduction

Requirements

Installation of Tools

Building the Application

Reference List

### Introduction

This file summarizes a simple project envolving techiques and knowledge points required for an SRE position. The poject consists of the following files:

1. README.md
2. A configuration file from /.kube/config, which records the configuration of the Kubernetes cluster.
3. main.go for receiving HTTP requests and printing the hello world message.
4. Dockerfile for building docker images.
5. deployment.yaml and service.yaml
6. dashboard-adminuser.yaml and kubernetes-dashboard-deployment.yml

External link to figures and sample outputs: 

https://drive.google.com/file/d/1ZY6SBVvhw4JYCJCkvSVvVTMo27AVZyW-/view?usp=sharing 

### Requirements

Guest OS: Ubuntu 18.04.5 LTS (Bionic Beaver), 64-bit PC (AMD64) server. See [[1]](https://releases.ubuntu.com/18.04.5/) for installation. 

VM system setting: 2 x vCPUs, 4GB RAM.

VM network setting: NAT with port forwarding of the following pairs: 2222:22 (SSH), 3100:3100, 31081:8443 (for future usage explained in preceding sections).

To allow SSH access:[[2]](https://ubuntu.com/server/docs/service-openssh). For this project, we should install the OpenSSH server on the guest OS. 

The firewall was disabled for troubleshooting purpose. See [[3]](https://www.digitalocean.com/community/tutorials/how-to-set-up-a-firewall-with-ufw-on-ubuntu-18-04) for setting up the Firewall with UFW.

Allow SSH access from the host:
`$ sudo ufw allow OpenSSH`

Allow access from any port:
`$ sudo ufw allow PORT_NUMBER`

Disable the Firewall:
$ sudo ufw disable`

Find the IP address to SSH to:
    $ ifconfig

For NAT network, we can use loopback address 127.0.0.1. 

On the SSH client: ssh USERNAME@127.0.0.1 -p 2222

Tools used (will be explained in following sections): Docker engine, Gogs, Kind, Kubernetes.

Other requirements: Git, Go and Kubectl pre-installed on the guest OS. A Dockerhub account for pushing images. Note that for Go, instead of using `sudo apt-get install`, we should install a newer version using `wget`. Ref:[[4]](https://linuxize.com/post/how-to-install-go-on-ubuntu-18-04/) The version used in this project was 1.16.


### Installation of Tools

#### 1. Upgrade the Ubuntu Kernel


Update the package index and upgrade packages:
    $ sudo apt update && sudo apt upgrade -y

Install the LTS enablement stacks:
    $ sudo apt-get install --install-recommends linux-generic-hwe-18.04


Then disconnect and reboot the machine.

Check current version of kernel:
    $ uname -r

The expected output is 5.4.0-80-generic.


#### 2. Install Docker Engine

Unintall old versions: 
    $ sudo apt-get remove docker docker-engine docker.io containerd runc

Set up the repository:
    $ sudo apt-get update
    $ sudo apt-get install apt-transport-https ca-certificates curl gnupg lsb-release

Add the GPG key:

    $ curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

Set up the stable repository:
    $ echo \
      "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable nightly" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null


Install Docker Engine:
    $ sudo apt-get install docker-ce docker-ce-cli containerd.io

Check the current version of Docker, the client and server should match:
    $ docker version


#### 3. Install Gogs

Before shipping Gogs with Docker, make sure to create a docker volume for it, so its configuration can be preserved.
    $ docker volume create my-vol
    $ docker volume inspect my-vol

Notice the mountpoint in the output.

Install using docker image:
    $ docker run -d --name=gogs -p 10022:22 -p 3100:3000 -v my-vol:/data gogs/gogs

In the above example, we run the container in detached mode and match port 3100 with the container port 3000. For this project, only the first port number(10022) can be different, since 22 and 3000 are required by Gogs image, and we want to access the web page via port 3100 (port-forwarding set up ahead).


Open the browser, access gogs via http://127.0.0.1:3100, and modify the following parameters:

Database Type (SQLite3), Domain (127.0.0.1), SSH Port (10022), check "Use Builtin SSH Server", 
HTTP Port (3000), Application URL (http://127.0.0.1:3100/), and admin user information.

Check "Enable Require Sign In to View Pages" in order to make it more secure.

In Gogs, we can create the repository on the left. Before creating the repo, create an organization called demo. Set the repo name to be go-web-hello-world and add the README.md file.


#### 4. Install Kind


For this project, we are utilizing a local Kubernetes cluster with only one node. 

Installation of kind (with newer version of Go):
    $ GO111MODULE="on" go get sigs.k8s.io/kind@v0.11.1


Before installation, make sure Go has not been initialized with a module.

Create a cluster:
    $ kind create cluster

Check the information of the cluster, nodes and pods:
    $ kubectl cluster-info --context kind-kind
    $ kubectl get nodes
    $ kubectl get pods


One cluster named kind and a node named kind-control-plane should have been created, with no active pod present.



### Building the Application

#### 1. Write up main.go

main.go consists of import statements, a web page handler function and the main function. The main function listens on port 8081, which would be the container port for the application image.

To test the code:
    $ go run main.go

In another terminal window, check the web page content:
    $ curl http://127.0.0.1:8081


#### 2. Write Dockerfile and build the image.

In the Dockerfile, docker builds the image in 2 stages, first from go and then from alpine. An earlier go version (1.8) was used to reduce the size of the image.

Build  and tag the image:
    $ docker build -t xuemengs/go-web-hello-app:v1 .

Run it in a container and map port 8082 to it:
    $ docker run -d -p 8082:8081 xuemengs/go-web-hello-app:v1


Check whether it is functional:
    $ curl http://127.0.0.1:8082

The compressed size of the container image (go-web-hello-app:v1) is 4.66 MB (as published on Dockerhub). The size can be further reduced by using even smaller base images. For this project, I chose golang:1.8-alpine3.6 and alpine:3.6. The lite version (go-web-hello-app:v3.lite) has a compressed size of 3.9 MB.


#### 3. Write deployment.yaml, service.yaml, and deploy the application in Kubernetes

First check used images and clean them up, since we don't want them to block the ports:
    $ docker ps -a
    $ docker rm CONTAINER_ID
    $ docker images
    $ docker rmi IMAGE_ID


Note that there are images with <none> as names. This is because they are intermediate image layers under the final images. In this case, we should not remove them.

deployment.yaml defines the Kubernetes Deployment, and service.yaml defines the NodePort. The value of nodePort was 31080.

Apply both files:
    $ kubectl apply -f deployment.yaml
    $ kubectl apply -f service.yaml


Check whether they are functional, if so, the status should be ready 1/1:
    $ kubectl get deployments
    $ kubectl get svc
    $ kubectl get pods


Check the IP address of the cluster:
    $ kubectl get nodes -o yaml | grep address

In my case, the IP address is 172.19.0.2

Check the web page content
    $ curl http://172.19.0.2:31080


#### 4. Install Kubernetes Dashboard

The general method is to use the recommended settings. However, for this project, we need to make modifications to the yaml file in order to expose the service as a NodePort.[https://computingforgeeks.com/how-to-install-kubernetes-dashboard-with-nodeport/]


Download the reconmmed.yaml and rename:

    $ wget https://raw.githubusercontent.com/kubernetes/dashboard/master/aio/deploy/recommended.yaml
    $ mv recommended.yaml kubernetes-dashboard-deployment.yml


Use nano or vim to edit:
    $ nano kubernetes-dashboard-deployment.yml


Browse throught the file, find the Service named kubernetes-dashboard, and change its type from ClusterIP to NodePort.
In spec.ports, add the nodePort value 31081.


Apply the file:
    $ kubectl apply -f kubernetes-dashboard-deployment.yml


Apply port forwarding, so we could access it through a browser on the host machine:
    $ kubectl port-forward -n kubernetes-dashboard service/kubernetes-dashboard 8443:443 --address 0.0.0.0


In this case, we forward port 8443 to port 443, which has mapped to port 31081. 


Open the browser and access the Kubernetes Dashboard with the following address:
https://127.0.0.1:31081/, and we should be asked for a login token.


Write a file called dashboard-adminuser.yaml to create a user[[[5]](https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md):
    $ kubectl apply -f dashboard-adminuser.yaml


Get the token to login:
    $ kubectl -n kubernetes-dashboard get secret
Notice the secret name in the first collumn.
    $ kubectl -n kube-system describe secret SECRET_NAME


#### 5. Build Gogs Container Image

After successfully configuring Gogs, stop the container:
    $ docker stop CONTAINER_ID
    
Commit the docker image of the container:
    $ docker commit CONTAINER_ID

Tag and push it to Dockerhub:
    $ docker tag IMAGE_ID USERNAME/repo:tag
    
Restart the container, browse http://127.0.0.1:3100, and a login page should appear:
    $ docker start CONTAINER_ID


### Reference List

https://releases.ubuntu.com/18.04.5

https://ubuntu.com/server/docs/service-openssh

https://www.digitalocean.com/community/tutorials/how-to-set-up-a-firewall-with-ufw-on-ubuntu-18-04

https://linuxize.com/post/how-to-install-go-on-ubuntu-18-04/

https://wiki.ubuntu.com/Kernel/LTSEnablementStack

https://docs.docker.com/install/linux/docker-ce/ubuntu/

https://github.com/gogs/gogs/tree/main/docker 

https://kind.sigs.k8s.io/docs/user/quick-start/

https://cloud.google.com/kubernetes-engine/docs/quickstart

https://kubernetes.io/docs/tasks/access-application-cluster/web-ui-dashboard/

https://computingforgeeks.com/how-to-install-kubernetes-dashboard-with-nodeport/

https://github.com/kubernetes/dashboard/blob/master/docs/user/access-control/creating-sample-user.md

